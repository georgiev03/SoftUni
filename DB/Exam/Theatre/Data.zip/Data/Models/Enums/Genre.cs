﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Theatre.Data.Models.Enums
{
    public enum Genre
    {
        Drama,
        Comedy, 
        Romance, 
        Musical
    }
}
