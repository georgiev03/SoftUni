﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.,1433;Database=TeisterMask;User Id=sa;Password=Jorkata03;";
    }
}
