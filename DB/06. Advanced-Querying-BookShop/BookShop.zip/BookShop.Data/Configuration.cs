﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 

            => "Server=.,1433;Database=BookShop;User Id=sa;Password=Jorkata03;";
    }
}
