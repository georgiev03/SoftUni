﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data.Models.Enumerations
{
    public enum Prediction
    {
        Draw = 0,
        Home = 1,
        Away = 2
    }
}
