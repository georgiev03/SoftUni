﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string CONNECTION_STRING =
            @"Server=.,1433;Database=StudentSystem;User Id=sa;Password=Jorkata03;";
    }
}
