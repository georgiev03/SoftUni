﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=.,1433;Database=VaporStore;User Id=sa;Password=Jorkata03;";
	}
}