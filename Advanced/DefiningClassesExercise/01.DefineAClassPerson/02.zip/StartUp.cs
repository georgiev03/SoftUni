﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person pesho = new Person
            {
                Name = "Pesho",
                Age = 24
            };

            Console.WriteLine($"{pesho.Name} - {pesho.Age}");
            
            var noName = new Person();
            Console.WriteLine($"{noName.Name} - {noName.Age}");

            var george = new Person(24);
            Console.WriteLine($"{george.Name} - {george.Age}");

            var ivan = new Person("Ivan", 20);

            Console.WriteLine($"{ivan.Name} - {ivan.Age}");

        }
    }
}
